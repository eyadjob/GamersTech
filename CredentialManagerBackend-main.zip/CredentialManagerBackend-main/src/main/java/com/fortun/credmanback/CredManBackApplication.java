package com.fortun.credmanback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CredManBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(CredManBackApplication.class, args);
    }

}
