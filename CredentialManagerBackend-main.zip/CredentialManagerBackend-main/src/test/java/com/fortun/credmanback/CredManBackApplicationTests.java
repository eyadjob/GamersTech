package com.fortun.credmanback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CredManBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
